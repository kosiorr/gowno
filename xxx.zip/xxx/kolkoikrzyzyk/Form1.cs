﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace KolkoIKrzyzyk
{
    public partial class Form1 : Form
    {
        private int[,] plansza = new int[3, 3];
        private int gracz = 1; // Gracz 1 to "X", gracz 2 to "O"

        public Form1()
        {
            InitializeComponent();
            Start();
        }

        private void Start()
        {
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    plansza[i, j] = 0;

            gracz = 1;
            canvas.Paint += new PaintEventHandler(Rysuj);
            canvas.MouseClick += new MouseEventHandler(Ruch);
        }

        private void Rysuj(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Color.White);

            for (int i = 1; i < 3; i++)
            {
                g.DrawLine(Pens.Black, i * 100, 0, i * 100, 300);
                g.DrawLine(Pens.Black, 0, i * 100, 300, i * 100);
            }

            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                {
                    if (plansza[i, j] == 1)
                    {
                        g.DrawLine(Pens.Black, i * 100 + 10, j * 100 + 10, i * 100 + 90, j * 100 + 90);
                        g.DrawLine(Pens.Black, i * 100 + 10, j * 100 + 90, i * 100 + 90, j * 100 + 10);
                    }
                    else if (plansza[i, j] == 2)
                    {
                        g.DrawEllipse(Pens.Black, i * 100 + 10, j * 100 + 10, 80, 80);
                    }
                }
        }

        private void Ruch(object sender, MouseEventArgs e)
        {
            int x = e.X / 100;
            int y = e.Y / 100;

            if (plansza[x, y] == 0)
            {
                plansza[x, y] = gracz;
                canvas.Invalidate();

                if (Wygrana(gracz))
                {
                    MessageBox.Show("Gracz " + gracz + " wygrywa!");
                    Start();
                }
                else if (Remis())
                {
                    MessageBox.Show("Remis!");
                    Start();
                }

                gracz = (gracz == 1) ? 2 : 1;

                if (gracz == 2)
                {
                    WykonajRuchKomputera();
                    canvas.Invalidate();

                    if (Wygrana(gracz))
                    {
                        MessageBox.Show("Gracz " + gracz + " wygrywa!");
                        Start();
                    }
                    else if (Remis())
                    {
                        MessageBox.Show("Remis!");
                        Start();
                    }

                    gracz = 1;
                }
            }
        }

        private bool Wygrana(int gracz)
        {
            for (int i = 0; i < 3; i++)
            {
                if (plansza[i, 0] == gracz && plansza[i, 1] == gracz && plansza[i, 2] == gracz)
                    return true;

                if (plansza[0, i] == gracz && plansza[1, i] == gracz && plansza[2, i] == gracz)
                    return true;
            }

            if (plansza[0, 0] == gracz && plansza[1, 1] == gracz && plansza[2, 2] == gracz)
                return true;

            if (plansza[2, 0] == gracz && plansza[1, 1] == gracz && plansza[0, 2] == gracz)
                return true;

            return false;
        }

        private bool Remis()
        {
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    if (plansza[i, j] == 0)
                        return false;

            return true;
        }

        private void WykonajRuchKomputera()
        {
            int x = -1, y = -1;
            int mmx = -10;

            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    if (plansza[i, j] == 0)
                    {
                        plansza[i, j] = 2;
                        int m = Minimax(plansza, 2);
                        plansza[i, j] = 0;

                        if (m > mmx)
                        {
                            mmx = m;
                            x = i;
                            y = j;
                        }
                    }

            if (x >= 0 && y >= 0)
                plansza[x, y] = 2;
        }

        private int Minimax(int[,] t, int gracz)
        {
            if (Wygrana(gracz))
                return (gracz == 2) ? 1 : -1;

            if (Remis())
                return 0;

            gracz = (gracz == 2) ? 1 : 2;
            int mmx = (gracz == 1) ? 10 : -10;

            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    if (t[i, j] == 0)
                    {
                        t[i, j] = gracz;
                        int m = Minimax(t, gracz);
                        t[i, j] = 0;

                        if (((gracz == 1) && (m < mmx)) || ((gracz == 2) && (m > mmx)))
                            mmx = m;
                    }

            return mmx;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}